<?php
// Server
define('DB_HOST', "localhost");
define('DB_USERNAME', "u977614154_anklee");
define('DB_PASSWORD', "Db_apps_123");
define('DB_NAME', "u977614154_db_apps_devlee");

// Local
// define('DB_HOST', "localhost");
// define('DB_USERNAME', "root");
// define('DB_PASSWORD', "");
// define('DB_NAME', "db_hnd_asignments");
